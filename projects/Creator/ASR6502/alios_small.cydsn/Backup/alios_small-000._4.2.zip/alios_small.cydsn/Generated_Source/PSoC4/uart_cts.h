/*******************************************************************************
* File Name: uart_cts.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_uart_cts_H) /* Pins uart_cts_H */
#define CY_PINS_uart_cts_H

#include "cytypes.h"
#include "cyfitter.h"
#include "uart_cts_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} uart_cts_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   uart_cts_Read(void);
void    uart_cts_Write(uint8 value);
uint8   uart_cts_ReadDataReg(void);
#if defined(uart_cts__PC) || (CY_PSOC4_4200L) 
    void    uart_cts_SetDriveMode(uint8 mode);
#endif
void    uart_cts_SetInterruptMode(uint16 position, uint16 mode);
uint8   uart_cts_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void uart_cts_Sleep(void); 
void uart_cts_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(uart_cts__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define uart_cts_DRIVE_MODE_BITS        (3)
    #define uart_cts_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - uart_cts_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the uart_cts_SetDriveMode() function.
         *  @{
         */
        #define uart_cts_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define uart_cts_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define uart_cts_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define uart_cts_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define uart_cts_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define uart_cts_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define uart_cts_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define uart_cts_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define uart_cts_MASK               uart_cts__MASK
#define uart_cts_SHIFT              uart_cts__SHIFT
#define uart_cts_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in uart_cts_SetInterruptMode() function.
     *  @{
     */
        #define uart_cts_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define uart_cts_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define uart_cts_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define uart_cts_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(uart_cts__SIO)
    #define uart_cts_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(uart_cts__PC) && (CY_PSOC4_4200L)
    #define uart_cts_USBIO_ENABLE               ((uint32)0x80000000u)
    #define uart_cts_USBIO_DISABLE              ((uint32)(~uart_cts_USBIO_ENABLE))
    #define uart_cts_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define uart_cts_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define uart_cts_USBIO_ENTER_SLEEP          ((uint32)((1u << uart_cts_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << uart_cts_USBIO_SUSPEND_DEL_SHIFT)))
    #define uart_cts_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << uart_cts_USBIO_SUSPEND_SHIFT)))
    #define uart_cts_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << uart_cts_USBIO_SUSPEND_DEL_SHIFT)))
    #define uart_cts_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(uart_cts__PC)
    /* Port Configuration */
    #define uart_cts_PC                 (* (reg32 *) uart_cts__PC)
#endif
/* Pin State */
#define uart_cts_PS                     (* (reg32 *) uart_cts__PS)
/* Data Register */
#define uart_cts_DR                     (* (reg32 *) uart_cts__DR)
/* Input Buffer Disable Override */
#define uart_cts_INP_DIS                (* (reg32 *) uart_cts__PC2)

/* Interrupt configuration Registers */
#define uart_cts_INTCFG                 (* (reg32 *) uart_cts__INTCFG)
#define uart_cts_INTSTAT                (* (reg32 *) uart_cts__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define uart_cts_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(uart_cts__SIO)
    #define uart_cts_SIO_REG            (* (reg32 *) uart_cts__SIO)
#endif /* (uart_cts__SIO_CFG) */

/* USBIO registers */
#if !defined(uart_cts__PC) && (CY_PSOC4_4200L)
    #define uart_cts_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define uart_cts_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define uart_cts_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define uart_cts_DRIVE_MODE_SHIFT       (0x00u)
#define uart_cts_DRIVE_MODE_MASK        (0x07u << uart_cts_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins uart_cts_H */


/* [] END OF FILE */

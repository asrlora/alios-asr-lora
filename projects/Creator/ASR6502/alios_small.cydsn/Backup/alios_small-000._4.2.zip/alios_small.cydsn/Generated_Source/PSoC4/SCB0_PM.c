/***************************************************************************//**
* \file SCB0_PM.c
* \version 4.0
*
* \brief
*  This file provides the source code to the Power Management support for
*  the SCB Component.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SCB0.h"
#include "SCB0_PVT.h"

#if(SCB0_SCB_MODE_I2C_INC)
    #include "SCB0_I2C_PVT.h"
#endif /* (SCB0_SCB_MODE_I2C_INC) */

#if(SCB0_SCB_MODE_EZI2C_INC)
    #include "SCB0_EZI2C_PVT.h"
#endif /* (SCB0_SCB_MODE_EZI2C_INC) */

#if(SCB0_SCB_MODE_SPI_INC || SCB0_SCB_MODE_UART_INC)
    #include "SCB0_SPI_UART_PVT.h"
#endif /* (SCB0_SCB_MODE_SPI_INC || SCB0_SCB_MODE_UART_INC) */


/***************************************
*   Backup Structure declaration
***************************************/

#if(SCB0_SCB_MODE_UNCONFIG_CONST_CFG || \
   (SCB0_SCB_MODE_I2C_CONST_CFG   && (!SCB0_I2C_WAKE_ENABLE_CONST))   || \
   (SCB0_SCB_MODE_EZI2C_CONST_CFG && (!SCB0_EZI2C_WAKE_ENABLE_CONST)) || \
   (SCB0_SCB_MODE_SPI_CONST_CFG   && (!SCB0_SPI_WAKE_ENABLE_CONST))   || \
   (SCB0_SCB_MODE_UART_CONST_CFG  && (!SCB0_UART_WAKE_ENABLE_CONST)))

    SCB0_BACKUP_STRUCT SCB0_backup =
    {
        0u, /* enableState */
    };
#endif


/*******************************************************************************
* Function Name: SCB0_Sleep
****************************************************************************//**
*
*  Prepares the SCB0 component to enter Deep Sleep.
*  The “Enable wakeup from Deep Sleep Mode” selection has an influence on this 
*  function implementation:
*  - Checked: configures the component to be wakeup source from Deep Sleep.
*  - Unchecked: stores the current component state (enabled or disabled) and 
*    disables the component. See SCB_Stop() function for details about component 
*    disabling.
*
*  Call the SCB0_Sleep() function before calling the 
*  CyPmSysDeepSleep() function. 
*  Refer to the PSoC Creator System Reference Guide for more information about 
*  power management functions and Low power section of this document for the 
*  selected mode.
*
*  This function should not be called before entering Sleep.
*
*******************************************************************************/
void SCB0_Sleep(void)
{
#if(SCB0_SCB_MODE_UNCONFIG_CONST_CFG)

    if(SCB0_SCB_WAKE_ENABLE_CHECK)
    {
        if(SCB0_SCB_MODE_I2C_RUNTM_CFG)
        {
            SCB0_I2CSaveConfig();
        }
        else if(SCB0_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            SCB0_EzI2CSaveConfig();
        }
    #if(!SCB0_CY_SCBIP_V1)
        else if(SCB0_SCB_MODE_SPI_RUNTM_CFG)
        {
            SCB0_SpiSaveConfig();
        }
        else if(SCB0_SCB_MODE_UART_RUNTM_CFG)
        {
            SCB0_UartSaveConfig();
        }
    #endif /* (!SCB0_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        SCB0_backup.enableState = (uint8) SCB0_GET_CTRL_ENABLED;

        if(0u != SCB0_backup.enableState)
        {
            SCB0_Stop();
        }
    }

#else

    #if (SCB0_SCB_MODE_I2C_CONST_CFG && SCB0_I2C_WAKE_ENABLE_CONST)
        SCB0_I2CSaveConfig();

    #elif (SCB0_SCB_MODE_EZI2C_CONST_CFG && SCB0_EZI2C_WAKE_ENABLE_CONST)
        SCB0_EzI2CSaveConfig();

    #elif (SCB0_SCB_MODE_SPI_CONST_CFG && SCB0_SPI_WAKE_ENABLE_CONST)
        SCB0_SpiSaveConfig();

    #elif (SCB0_SCB_MODE_UART_CONST_CFG && SCB0_UART_WAKE_ENABLE_CONST)
        SCB0_UartSaveConfig();

    #else

        SCB0_backup.enableState = (uint8) SCB0_GET_CTRL_ENABLED;

        if(0u != SCB0_backup.enableState)
        {
            SCB0_Stop();
        }

    #endif /* defined (SCB0_SCB_MODE_I2C_CONST_CFG) && (SCB0_I2C_WAKE_ENABLE_CONST) */

#endif /* (SCB0_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: SCB0_Wakeup
****************************************************************************//**
*
*  Prepares the SCB0 component for Active mode operation after 
*  Deep Sleep.
*  The “Enable wakeup from Deep Sleep Mode” selection has influence on this 
*  function implementation:
*  - Checked: restores the component Active mode configuration.
*  - Unchecked: enables the component if it was enabled before enter Deep Sleep.
*
*  This function should not be called after exiting Sleep.
*
*  \sideeffect
*   Calling the SCB0_Wakeup() function without first calling the 
*   SCB0_Sleep() function may produce unexpected behavior.
*
*******************************************************************************/
void SCB0_Wakeup(void)
{
#if(SCB0_SCB_MODE_UNCONFIG_CONST_CFG)

    if(SCB0_SCB_WAKE_ENABLE_CHECK)
    {
        if(SCB0_SCB_MODE_I2C_RUNTM_CFG)
        {
            SCB0_I2CRestoreConfig();
        }
        else if(SCB0_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            SCB0_EzI2CRestoreConfig();
        }
    #if(!SCB0_CY_SCBIP_V1)
        else if(SCB0_SCB_MODE_SPI_RUNTM_CFG)
        {
            SCB0_SpiRestoreConfig();
        }
        else if(SCB0_SCB_MODE_UART_RUNTM_CFG)
        {
            SCB0_UartRestoreConfig();
        }
    #endif /* (!SCB0_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        if(0u != SCB0_backup.enableState)
        {
            SCB0_Enable();
        }
    }

#else

    #if (SCB0_SCB_MODE_I2C_CONST_CFG  && SCB0_I2C_WAKE_ENABLE_CONST)
        SCB0_I2CRestoreConfig();

    #elif (SCB0_SCB_MODE_EZI2C_CONST_CFG && SCB0_EZI2C_WAKE_ENABLE_CONST)
        SCB0_EzI2CRestoreConfig();

    #elif (SCB0_SCB_MODE_SPI_CONST_CFG && SCB0_SPI_WAKE_ENABLE_CONST)
        SCB0_SpiRestoreConfig();

    #elif (SCB0_SCB_MODE_UART_CONST_CFG && SCB0_UART_WAKE_ENABLE_CONST)
        SCB0_UartRestoreConfig();

    #else

        if(0u != SCB0_backup.enableState)
        {
            SCB0_Enable();
        }

    #endif /* (SCB0_I2C_WAKE_ENABLE_CONST) */

#endif /* (SCB0_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/* [] END OF FILE */

/*******************************************************************************
* File Name: set_a.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_set_a_H) /* Pins set_a_H */
#define CY_PINS_set_a_H

#include "cytypes.h"
#include "cyfitter.h"
#include "set_a_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} set_a_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   set_a_Read(void);
void    set_a_Write(uint8 value);
uint8   set_a_ReadDataReg(void);
#if defined(set_a__PC) || (CY_PSOC4_4200L) 
    void    set_a_SetDriveMode(uint8 mode);
#endif
void    set_a_SetInterruptMode(uint16 position, uint16 mode);
uint8   set_a_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void set_a_Sleep(void); 
void set_a_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(set_a__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define set_a_DRIVE_MODE_BITS        (3)
    #define set_a_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - set_a_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the set_a_SetDriveMode() function.
         *  @{
         */
        #define set_a_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define set_a_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define set_a_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define set_a_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define set_a_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define set_a_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define set_a_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define set_a_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define set_a_MASK               set_a__MASK
#define set_a_SHIFT              set_a__SHIFT
#define set_a_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in set_a_SetInterruptMode() function.
     *  @{
     */
        #define set_a_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define set_a_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define set_a_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define set_a_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(set_a__SIO)
    #define set_a_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(set_a__PC) && (CY_PSOC4_4200L)
    #define set_a_USBIO_ENABLE               ((uint32)0x80000000u)
    #define set_a_USBIO_DISABLE              ((uint32)(~set_a_USBIO_ENABLE))
    #define set_a_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define set_a_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define set_a_USBIO_ENTER_SLEEP          ((uint32)((1u << set_a_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << set_a_USBIO_SUSPEND_DEL_SHIFT)))
    #define set_a_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << set_a_USBIO_SUSPEND_SHIFT)))
    #define set_a_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << set_a_USBIO_SUSPEND_DEL_SHIFT)))
    #define set_a_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(set_a__PC)
    /* Port Configuration */
    #define set_a_PC                 (* (reg32 *) set_a__PC)
#endif
/* Pin State */
#define set_a_PS                     (* (reg32 *) set_a__PS)
/* Data Register */
#define set_a_DR                     (* (reg32 *) set_a__DR)
/* Input Buffer Disable Override */
#define set_a_INP_DIS                (* (reg32 *) set_a__PC2)

/* Interrupt configuration Registers */
#define set_a_INTCFG                 (* (reg32 *) set_a__INTCFG)
#define set_a_INTSTAT                (* (reg32 *) set_a__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define set_a_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(set_a__SIO)
    #define set_a_SIO_REG            (* (reg32 *) set_a__SIO)
#endif /* (set_a__SIO_CFG) */

/* USBIO registers */
#if !defined(set_a__PC) && (CY_PSOC4_4200L)
    #define set_a_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define set_a_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define set_a_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define set_a_DRIVE_MODE_SHIFT       (0x00u)
#define set_a_DRIVE_MODE_MASK        (0x07u << set_a_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins set_a_H */


/* [] END OF FILE */

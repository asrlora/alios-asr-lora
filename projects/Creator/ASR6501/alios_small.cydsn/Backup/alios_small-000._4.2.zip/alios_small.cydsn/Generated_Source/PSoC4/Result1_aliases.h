/*******************************************************************************
* File Name: Result1.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Result1_ALIASES_H) /* Pins Result1_ALIASES_H */
#define CY_PINS_Result1_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Result1_0			(Result1__0__PC)
#define Result1_0_PS		(Result1__0__PS)
#define Result1_0_PC		(Result1__0__PC)
#define Result1_0_DR		(Result1__0__DR)
#define Result1_0_SHIFT	(Result1__0__SHIFT)
#define Result1_0_INTR	((uint16)((uint16)0x0003u << (Result1__0__SHIFT*2u)))

#define Result1_INTR_ALL	 ((uint16)(Result1_0_INTR))


#endif /* End Pins Result1_ALIASES_H */


/* [] END OF FILE */

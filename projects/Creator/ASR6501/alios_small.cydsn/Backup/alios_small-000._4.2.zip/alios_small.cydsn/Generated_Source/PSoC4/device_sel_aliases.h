/*******************************************************************************
* File Name: device_sel.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_device_sel_ALIASES_H) /* Pins device_sel_ALIASES_H */
#define CY_PINS_device_sel_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define device_sel_0			(device_sel__0__PC)
#define device_sel_0_PS		(device_sel__0__PS)
#define device_sel_0_PC		(device_sel__0__PC)
#define device_sel_0_DR		(device_sel__0__DR)
#define device_sel_0_SHIFT	(device_sel__0__SHIFT)
#define device_sel_0_INTR	((uint16)((uint16)0x0003u << (device_sel__0__SHIFT*2u)))

#define device_sel_INTR_ALL	 ((uint16)(device_sel_0_INTR))


#endif /* End Pins device_sel_ALIASES_H */


/* [] END OF FILE */

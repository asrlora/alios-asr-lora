/*******************************************************************************
* File Name: wco_out.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_wco_out_ALIASES_H) /* Pins wco_out_ALIASES_H */
#define CY_PINS_wco_out_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define wco_out_0			(wco_out__0__PC)
#define wco_out_0_PS		(wco_out__0__PS)
#define wco_out_0_PC		(wco_out__0__PC)
#define wco_out_0_DR		(wco_out__0__DR)
#define wco_out_0_SHIFT	(wco_out__0__SHIFT)
#define wco_out_0_INTR	((uint16)((uint16)0x0003u << (wco_out__0__SHIFT*2u)))

#define wco_out_INTR_ALL	 ((uint16)(wco_out_0_INTR))


#endif /* End Pins wco_out_ALIASES_H */


/* [] END OF FILE */
